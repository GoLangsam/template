package template

import (
	"io"
	text "text/template"
	html "html/template"
)

/*
text\template
func (t *Template) Clone() (*Template, error)
func (t *Template) DefinedTemplates() string
func (t *Template) Delims(left, right string) *Template
func (t *Template) Execute(wr io.Writer, data interface{}) error
func (t *Template) ExecuteTemplate(wr io.Writer, name string, data interface{}) error
func (t *Template) Funcs(funcMap FuncMap) *Template
func (t *Template) Lookup(name string) *Template
func (t *Template) Name() string
func (t *Template) New(name string) *Template
func (t *Template) Option(opt ...string) *Template
func (t *Template) Parse(text string) (*Template, error)
func (t *Template) ParseFiles(filenames ...string) (*Template, error)
func (t *Template) ParseGlob(pattern string) (*Template, error)
func (t *Template) Templates() []*Template

html\template
func (t *Template) Clone() (*Template, error)
func (t *Template) DefinedTemplates() string
func (t *Template) Delims(left, right string) *Template
func (t *Template) Execute(wr io.Writer, data interface{}) error
func (t *Template) ExecuteTemplate(wr io.Writer, name string, data interface{}) error
func (t *Template) Funcs(funcMap FuncMap) *Template
func (t *Template) Lookup(name string) *Template
func (t *Template) Name() string
func (t *Template) New(name string) *Template
func (t *Template) Option(opt ...string) *Template
func (t *Template) Parse(src string) (*Template, error)
func (t *Template) ParseFiles(filenames ...string) (*Template, error)
func (t *Template) ParseGlob(pattern string) (*Template, error)
func (t *Template) Templates() []*Template
*/

type FuncMap map[string]interface{}

type GoTemplate interface {
	Clone() (GoTemplate, error)
	DefinedTemplates() string
	Delims(left, right string) GoTemplate
	Execute(wr io.Writer, data interface{}) error
	ExecuteTemplate(wr io.Writer, name string, data interface{}) error
	Funcs(funcMap FuncMap) GoTemplate
	Lookup(name string) GoTemplate
	Name() string
	New(name string) GoTemplate
	Option(opt ...string) GoTemplate
	Parse(src string) (GoTemplate, error)
	ParseFiles(filenames ...string) (GoTemplate, error)
	ParseGlob(pattern string) (GoTemplate, error)
	Templates() []GoTemplate
}

var _ GoTemplate = text.New("Interface ok?")
var _ GoTemplate = html.New("Interface ok?")
